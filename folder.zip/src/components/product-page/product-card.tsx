// src/components/product-page/product-card.tsx
import { useState } from "react";
import {
	Card,
	CardMedia,
	CardContent,
	Typography,
	Box,
	Chip,
	IconButton,
	Button,
	Divider,
} from "@mui/material";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import FavoriteIcon from "@mui/icons-material/Favorite";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import VisibilityIcon from "@mui/icons-material/Visibility";
import type { Product } from "../../config/types";
import { useAppContext } from "../../context/app-context";

interface Props {
	product: Product;
	onQuickView: (product: Product) => void;
}

export default function ProductCard({ product, onQuickView }: Props) {
	const { state, dispatch } = useAppContext();
	const [selectedColor, setSelectedColor] = useState(product.colors[0]);
	const isWishlisted = state.wishlist.some((p) => p.id === product.id);

	return (
		<Card
			sx={{
				height: "100%",
				display: "flex",
				flexDirection: "column",
				borderRadius: "16px", // Slightly larger radius for modern look
				overflow: "hidden",
				transition: "transform 0.3s ease, box-shadow 0.3s ease",
				"&:hover": {
					transform: "translateY(-4px)",
					boxShadow: (t) =>
						t.palette.mode === "light"
							? "0px 10px 30px rgba(0, 0, 0, 0.1)"
							: "0px 10px 30px rgba(0, 0, 0, 0.4)",
				},
			}}
		>
			{/* Image Section */}
			<Box
				sx={{
					position: "relative",
					backgroundColor: (t) =>
						t.palette.mode === "light" ? "#F5F5F5" : "#252525",
				}}
			>
				<CardMedia
					component="img"
					height="260"
					image={selectedColor.imageUrl}
					alt={product.name}
					loading="lazy"
					sx={{ objectFit: "cover" }}
				/>

				{/* Status Badge (Top Left) */}
				<Chip
					label={product.status.replace("_", " ")}
					size="small"
					sx={{
						position: "absolute",
						top: 16,
						left: 16,
						zIndex: 1,
						textTransform: "uppercase",
						fontWeight: 700,
						fontSize: "0.7rem",
						letterSpacing: "0.5px",
						backgroundColor: (t) =>
							product.status === "IN_STOCK"
								? t.palette.success.main
								: product.status === "COMING_SOON"
									? t.palette.warning.main
									: t.palette.error.main,
						color: "#fff",
						boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
						borderRadius: "4px", // Sharper badge to contrast rounded card
					}}
				/>

				{/* Wishlist Button (Top Right) */}
				<IconButton
					onClick={() =>
						dispatch({ type: "TOGGLE_WISHLIST", payload: product })
					}
					sx={{
						position: "absolute",
						top: 8,
						right: 8,
						backgroundColor: "rgba(255,255,255,0.8)",
						backdropFilter: "blur(4px)",
						"&:hover": { backgroundColor: "rgba(255,255,255,1)" },
						width: 36,
						height: 36,
					}}
				>
					{isWishlisted ? (
						<FavoriteIcon sx={{ fontSize: 18 }} color="error" />
					) : (
						<FavoriteBorderIcon sx={{ fontSize: 18 }} />
					)}
				</IconButton>
			</Box>

			{/* Content Section */}
			<CardContent
				sx={{
					p: 3,
					display: "flex",
					flexDirection: "column",
					flexGrow: 1,
				}}
			>
				{/* Category & Quick View */}
				<Box
					sx={{
						display: "flex",
						justifyContent: "space-between",
						alignItems: "center",
						mb: 1,
					}}
				>
					<Typography
						variant="overline"
						sx={{
							color: "text.secondary",
							fontWeight: 700,
							letterSpacing: "1px",
							fontSize: "0.7rem",
						}}
					>
						{product.category}
					</Typography>
					<IconButton
						size="small"
						onClick={() => onQuickView(product)}
						sx={{
							color: "text.secondary",
							"&:hover": { color: "primary.main" },
						}}
					>
						<VisibilityIcon fontSize="small" />
					</IconButton>
				</Box>

				{/* Title */}
				<Typography
					variant="h6"
					component="div"
					sx={{
						fontWeight: 700,
						mb: 1.5,
						lineHeight: 1.3,
						// Clamp to 2 lines
						display: "-webkit-box",
						WebkitLineClamp: 2,
						WebkitBoxOrient: "vertical",
						overflow: "hidden",
						minHeight: "3.9rem", // Prevent layout shift
					}}
				>
					{product.name}
				</Typography>

				{/* Color Selection */}
				<Box
					sx={{
						display: "flex",
						alignItems: "center",
						gap: 1,
						mb: 3,
					}}
				>
					{product.colors.map((color) => (
						<Box
							key={color.name}
							onClick={() => setSelectedColor(color)}
							sx={{
								width: 20,
								height: 20,
								borderRadius: "50%",
								backgroundColor: color.hex,
								border: (t) =>
									selectedColor.name === color.name
										? `2px solid ${t.palette.text.primary}`
										: "2px solid transparent",
								cursor: "pointer",
								transition:
									"border 0.2s ease, transform 0.2s ease",
								"&:hover": { transform: "scale(1.15)" },
							}}
						/>
					))}
					<Typography
						variant="caption"
						color="text.secondary"
						sx={{ ml: 1, fontWeight: 500 }}
					>
						{selectedColor.name}
					</Typography>
				</Box>

				<Box sx={{ flexGrow: 1 }} />

				<Divider sx={{ mb: 2 }} />

				{/* Price & CTA */}
				<Box
					sx={{
						display: "flex",
						justifyContent: "space-between",
						alignItems: "center",
					}}
				>
					<Box>
						<Typography
							variant="caption"
							color="text.secondary"
							sx={{ display: "block", lineHeight: 1 }}
						>
							Price
						</Typography>
						<Typography
							variant="h5"
							color="primary"
							sx={{ fontWeight: 800, lineHeight: 1.2 }}
						>
							${product.price.toFixed(2)}
						</Typography>
					</Box>

					<Button
						variant="contained"
						size="medium"
						startIcon={<ShoppingCartOutlinedIcon />}
						onClick={() =>
							dispatch({
								type: "ADD_TO_CART",
								payload: {
									product,
									selectedColorName: selectedColor.name,
									quantity: 1,
								},
							})
						}
						disabled={product.status === "OUT_OF_STOCK"}
						sx={{
							borderRadius: "8px",
							textTransform: "none",
							fontWeight: 600,
							px: 3,
							py: 1.2,
						}}
					>
						Add
					</Button>
				</Box>
			</CardContent>
		</Card>
	);
}
